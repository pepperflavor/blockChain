
//포커문양 뽑을 번호 받아줌
let Pic =0;
//하트 , 다이아, 클로버, 스페이드, 스페이드 에이스(웃는 검은얼굴)
let poket = ['&#9829;','&#9830;','&#9827;', ' &#9824;', '&#9787;' ];

console.log(poket);
document.write(poket);
// function pockerPic(poket){
//     Pic = Math.floor((Math.random()*3)); //배열인덱스랑 맞추기위해서 0~3범위에서 숫자뽑게함
//     for(let i=0; i<poket.lenght; i++){

//     }
// }